```javascript
const data = [
  { country: 'China', gold: 11, silver: 5, bronze: 8 },
  { country: 'Japan', gold: 11, silver: 4, bronze: 5 },
  { country: 'USA', gold: 10, silver: 11, bronze: 9 },
];
```
转化为
```javascript
{ country: 'China', medal: 'gold', value: 11 }
{ country: 'China', medal: 'silver', value: 5 }
{ country: 'China', medal: 'bronze', value: 8 }
...
```
