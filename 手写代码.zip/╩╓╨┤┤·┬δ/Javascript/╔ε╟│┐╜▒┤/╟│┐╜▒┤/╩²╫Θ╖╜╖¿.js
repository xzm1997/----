let arr = [1,2,3,4]
let newArr1 = arr.slice();
let newArr2 = arr.concat();
