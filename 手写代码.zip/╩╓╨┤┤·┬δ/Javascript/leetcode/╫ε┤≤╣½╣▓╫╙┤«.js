const findSubStr = function(str1, str2) {
  if (str1.length > str2.length) [str1, str2] = [str2, str1];
  let result = '';
  const len = str1.length;
  for (let j = len; j > 0; --j) {
    for (let i = 0; i <= len - j; ++i) {
      result = str1.substr(i, j);
      if (str2.includes(result)) return result
    }
  }
}


let str1 = 'apdfsasd';
let str2 = 'hsfsasewa'

console.log(findSubStr(str1, str2));
