function myStringify(obj) {
  
}
